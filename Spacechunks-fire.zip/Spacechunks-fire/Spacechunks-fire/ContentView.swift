//
//  ContentView.swift
//  Spacechunks-fire
//
//  Created by Gomathy Shankaran on 5/4/23.
//
import UIKit
import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseCore



// import FirebaseFirestore

struct spaceobj:Decodable,Identifiable {
    var id: String {title!}
    
  
  //  let copyright:String
    let date:String?
    let explanation:String?
   // let hdurl:String
    let media_type:String?
   // let service_version:String?
    var title:String? = "APOD Image"
    let url:String?
    
}

struct spaceobj1:Decodable,Identifiable {
    var id: String {title!}
    
  
  //  let copyright:String
    let date:String?
    let explanation:String?
 
    let media_type:String?
   
    var title:String?
    let url:String?
    
}
var dataDescription = ""
var db = Firestore.firestore()
struct ContentView: View {
   @State var i=0
    @State var qslink = ""
    @State var datef = DateFormatter()
    
    @State var bbackground = "https://www.kidzlearn.co/uploads/3/4/6/7/34677650/kingfisher_2.png"
   // @State var urlink = "https://firebasestorage.googleapis.com/v0/b/test-ade3c.appspot.com/o/spacechunks.json?alt=media"
    @State var urlink =
"https://firebasestorage.googleapis.com/v0/b/spacechunks-fire/o/spacechunks.json?alt=media"
    @State var qslinknew = "https://api.nasa.gov/planetary/apod?api_key=your api key"
  
    @State var bb1 = [spaceobj]()
    @State var ggum0 = Date()
    @State var ggum1 = Date()
    @State var ggum2 = Date()
    @State var ggum3 = Date()
    @State var ggum4 = Date()
    @State var ggum5 = Date()
    @State var ggum6 = Date()
    @State var ggum7 = Date()
    @State var ggum8 = Date()
    @State var ggum9 = Date()
    @State var bb3 : spaceobj1
    @State var aa0 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa1 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa2 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa3 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa4 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa5 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa6 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa7 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var aa8 = spaceobj1(date: "", explanation: "", media_type: "", url: "")
    @State var qslinknew0 = ""
    @State var qslinknew1 = ""
    @State var qslinknew2 = ""
    @State var qslinknew3 = ""
    @State var qslinknew4 = ""
    @State var qslinknew5 = ""
    @State var qslinknew6 = ""
    @State var qslinknew7 = ""
    @State var qslinknew8 = ""
    @State var showsub = false
    @State var apodtitle = "Apod"
    @State var ddate =  ""
    @State var showtext = false
    @State var bimage = UIImage()
    let remotec = RemoteConfig.remoteConfig()
    var body: some View {
       
        ScrollView(.vertical) {
            ZStack {
                
                VStack{
                    
                    
                    HStack {
                        Text("Space Chunks from NASA APOD")
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .padding(.all)
                        VStack {
                            Text(apodtitle)
                                .font(.body)
                                .background(Color.clear)
                                .bold()
                                .underline()
                                //.border(Color.blue)
                                .frame(width:200,height: 50,alignment: .center)
                                .padding(.all,10)
                                .onAppear {
                                    apodtitle = "Show \nExplanation"
                                }
                                .onTapGesture() {
                                    showtext.toggle()
                                    if showtext == false
                                    {
                                        apodtitle = "Show \nExplanation"
                                    }
                                    else
                                    {
                                        apodtitle = "Hide \nExplanation"
                                    }
                                    
                                }
                            
                            Text("Subscribe")
                                .font(.body)
                                .background(Color.clear)
                                .bold()
                                .underline()
                              //  .border(Color.blue)
                                .frame(width:200,height: 50,alignment: .center)
                                .padding(.all,10)
                                
                                
                                .onTapGesture() {
                                  showsub = true
                                      //  .frame(width: 250,height: 300,alignment: .center)
                
                                }.sheet(isPresented: $showsub, content: {
                                    SubscribeView()
                                    
                                })
                            
                        } // VStack
                    }
                    
                  //  Spacer()
                    
                    
                    if (bb3.media_type == "image")
                    {
                        Text(bb3.title! + " " + bb3.date!)
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .underline()
                        
                            .padding(.all,25)
                        
                        
                        
                        AsyncImage(url: URL(string: bb3.url!)) { image in image
                                .resizable()
                                .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                            
                        } placeholder: {
                            Image(systemName: "photo.fill")
                        }
                        .frame(width: 250, height: 250)
                        .padding(.all,25)
                        
                    }
                    
                    if (showtext == true) {
                        
                        
                        Text(bb3.explanation!)
                            .font(.body)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .padding(.all,25)
                        
                    }
                    //  autoimage
                    
                    
                    if (aa0.media_type == "image")
                    {
                        Text(aa0.title! + " " + aa0.date!)
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .underline()
                        
                            .padding(.all,25)
                        
                        
                        
                        AsyncImage(url: URL(string: aa0.url!)) { image in image
                                .resizable()
                                .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                            
                        } placeholder: {
                            Image(systemName: "photo.fill")
                        }
                        .frame(width: 250, height: 250)
                        .padding(.all,25)
                        
                        
                        
                        if (showtext == true) {
                            
                            
                            Text(aa0.explanation!)
                                .font(.body)
                                .foregroundColor(Color.black)
                                .kerning(0.5)
                                .bold()
                                .padding(.all,25)
                            
                            
                            
                        }
                        
                    }
                    
                    
                    if (aa1.media_type == "image")
                    {
                        Text(aa1.title! + " " + aa1.date!)
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .underline()
                        
                            .padding(.all,25)
                        
                        
                        
                        AsyncImage(url: URL(string: aa1.url!)) { image in image
                                .resizable()
                                .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                            
                        } placeholder: {
                            Image(systemName: "photo.fill")
                        }
                        .frame(width: 250, height: 250)
                        .padding(.all,25)
                        
                        
                        
                        if (showtext == true) {
                            
                            
                            Text(aa1.explanation!)
                                .font(.body)
                                .foregroundColor(Color.black)
                                .kerning(0.5)
                                .bold()
                                .padding(.all,25)
                            
                            
                            
                        }
                        
                    }
            
                    if (aa2.media_type == "image")
                    {
                        Text(aa2.title! + " " + aa2.date!)
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .underline()
                        
                            .padding(.all,25)
                        
                        
                        
                        AsyncImage(url: URL(string: aa2.url!)) { image in image
                                .resizable()
                                .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                            
                        } placeholder: {
                            Image(systemName: "photo.fill")
                        }
                        .frame(width: 250, height: 250)
                        .padding(.all,25)
                        
                        
                        
                        if (showtext == true) {
                            
                            
                            Text(aa2.explanation!)
                                .font(.body)
                                .foregroundColor(Color.black)
                                .kerning(0.5)
                                .bold()
                                .padding(.all,25)
                            
                            
                            
                        }
                        
                    }
            
                    if (aa3.media_type == "image")
                    {
                        Text(aa3.title! + " " + aa3.date!)
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .underline()
                        
                            .padding(.all,25)
                        
                        
                        
                        AsyncImage(url: URL(string: aa3.url!)) { image in image
                                .resizable()
                                .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                            
                        } placeholder: {
                            Image(systemName: "photo.fill")
                        }
                        .frame(width: 250, height: 250)
                        .padding(.all,25)
                        
                        
                        
                        if (showtext == true) {
                            
                            
                            Text(aa3.explanation!)
                                .font(.body)
                                .foregroundColor(Color.black)
                                .kerning(0.5)
                                .bold()
                                .padding(.all,25)
                            
                            
                            
                        }
                        
                    }
                    
                    if (aa4.media_type == "image")
                    {
                        Text(aa4.title! + " " + aa4.date!)
                            .font(.title)
                            .foregroundColor(Color.black)
                            .kerning(0.5)
                            .bold()
                            .underline()
                        
                            .padding(.all,25)
                        
                        
                        
                        AsyncImage(url: URL(string: aa4.url!)) { image in image
                                .resizable()
                                .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                            
                        } placeholder: {
                            Image(systemName: "photo.fill")
                        }
                        .frame(width: 250, height: 250)
                        .padding(.all,25)
                        
                        
                        
                        if (showtext == true) {
                            
                            
                            Text(aa4.explanation!)
                                .font(.body)
                                .foregroundColor(Color.black)
                                .kerning(0.5)
                                .bold()
                                .padding(.all,25)
                            
                            
                            
                        }
                        
                    }
                    
                        // autoimage
                        
                    ForEach( bb1)  { spaceobj in
                                            if (spaceobj.media_type == "image")
                                            {
                                                Text(spaceobj.title!)
                                                    .font(.title)
                                                    .foregroundColor(Color.black)
                                                    .kerning(0.5)
                                                    .bold()
                                                    .underline()
                                                    .padding(.all,25)
                                                    
                                               
                                            //    Image(uiImage: UIImage(data:try!Data(contentsOf:URL(string:spaceobj.url!)!))!)
                                                
                                                AsyncImage(url: URL(string: spaceobj.url!)) { image in image
                                                    .resizable()
                                                    .frame(width:UIScreen.main.bounds.width - 20,height: UIScreen.main.bounds.height/2.5)
                                                  //  .aspectRatio(contentMode: .fit)
                                                } placeholder: {
                                                    Image(systemName: "photo.fill")
                                                }
                                                .frame(width: 250, height: 250)
                                                    .padding(.all,25)
                                                
                                                   
                                                
                                                // explanation
                                                if (showtext == true && spaceobj.id == spaceobj.title!) {
                                               
                                                   
                                                        Text(spaceobj.explanation!)
                                                            .font(.body)
                                                            .foregroundColor(Color.black)
                                                            .kerning(0.5)
                                                            .bold()
                                                            .padding(.all,25)
                                                        
                                                    }
                                                    //explanation
                                               
                                            }
                                            
                                            }.onAppear {
                                                i = i + 1
                                            }

                       
                    
                    }.onAppear {
                        
                        
                        datef.dateStyle = .long
                        datef.timeStyle = .none
                        datef.dateFormat = "yyyy-MM-dd"
                        let ddum = Date.now.formatted(.dateTime.day(.twoDigits))
                        let mmum = Date.now.formatted(.dateTime.month(.twoDigits))
                        let yyum = Date.now.formatted(.dateTime.year())
                     //     let ggum0 = String(yyum) + "-" + mmum + "-" + String(Int(ddum)!)
                       
                         ggum1 = Date.now - (86400 * 2)
                         ggum2 = Date.now - (86400 * 3)
                         ggum3 = Date.now - (86400 * 4)
                         ggum4 = Date.now - (86400 * 5)
                         ggum5 = Date.now - (86400 * 6)
                         ggum6 = Date.now - (86400 * 7)
                         ggum7 = Date.now - (86400 * 8)
                         ggum8 = Date.now - (86400 * 9)
                         ggum9 = Date.now - (86400 * 10)
                        let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "yyyy-MM-dd"
                        ggum0 = Date() - (86400 * 1)
                        
                        let dinputtoken = db.collection("redact").document("nasdoc")
                       
                        dinputtoken.getDocument{ (document, error) in
                           if let document = document, document.exists {
                           //    dataDescription = document.get("input")! as! String
                               
                              
                               
                             
                     //      } else {
                    //            print("Document does not exist")
                    //        }
                   //     }
                       // let dinputtoken =  db.collection("redact").whereField("input", isEqualTo: true)
                            
                   //     print("database1",dataDescription)
                      //  qslinknew0 = dataDescription + "&date=" + dateFormatter.string(from: ggum0)
                               qslinknew0 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum0)
                    //    print("database1",dataDescription,qslinknew0)
                        qslinknew1 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum1)
                        qslinknew2 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum2)
                        qslinknew3 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum3)
                        qslinknew4 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum4)
                        qslinknew5 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum5)
                        print("date 1=",ggum0, (Date.now - (86400 * 7)))
                        qslinknew6 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum6)
                        qslinknew7 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum7)
                        qslinknew8 = "https://api.nasa.gov/planetary/apod?api_key=your apikey" + dateFormatter.string(from: ggum8)
                        print("date 1=",ggum0, (Date.now - (86400 * 7)))
                       
                       
                        bbk()
                           bb()
                       
                        
                        aat()
                        aat0()
                        aat1()
                        aat2()
                        aat3()
                        aat4()
                        aat5()
                        aat6()
                        aat7()
                          // db
                           } else {
                                      print("Document does not exist")
                                }
                              }
                        // db
                    }
                
            }
                
        } .background(
            
            AsyncImage(url: URL(string:bbackground)) {
            image in image
       .resizable()
       .frame(width:UIScreen.main.bounds.width,height: UIScreen.main.bounds.height)
       .aspectRatio(contentMode: .fit)

    }placeholder: {
    Image(systemName: "photo.fill")
    }


    )

   // .edgesIgnoringSafeArea(.all)
    // .ignoresSafeArea(.all)
    }
    //  **********
    func aat()
    {
        
      //  print("qslinknew0",qslinknew0)
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew0)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bbn: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa0 = bbn
             //   print(aa0.title!,aa0.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
    }
    
    func aat0()
    {
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew1)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bbn: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa1 = bbn
             //   print(aa0.title!,aa0.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
    }
    
    func aat1()
    {
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew2)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bbn1: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa2 = bbn1
            //    print(aa2.title!,aa2.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
    }
    
    func aat2()
    {
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew3)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bbn2: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa3 = bbn2
              //  print(aa3.title!,aa3.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
    }
    
    func aat3()
    {
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew4)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bbn3: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa4 = bbn3
              //  print(aa3.title!,aa3.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
    }
    
    func aat4()
    {
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew5)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
              //  try JSONDecoder().decode([spaceobj].self, from: data!)
                let bbn4: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa5 = bbn4
                //    print(aa3.title!,aa3.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
        
        
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew6)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bbn5: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                aa5 = bbn5
              //  print(aa5.title!,aa5.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
    }
        func aat5()
        {
            URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew6)!) as URLRequest) {(data1,reponse,error) in
                do
                {
                    // let JSON = ""
                    //  let jsonData = JSON.data(using: .utf8)!
                    let bbn5: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                    aa6 = bbn5
                //    print(aa3.title!,aa3.media_type!)
                    
                }
                catch {
                    print("Error",error)
                }
                
            }.resume()
    }
        
        func aat6()
        {
            URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew7)!) as URLRequest) {(data1,reponse,error) in
                do
                {
                    // let JSON = ""
                    //  let jsonData = JSON.data(using: .utf8)!
                    let bbn6: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                    aa7 = bbn6
                    //    print(aa3.title!,aa3.media_type!)
                    
                }
                catch {
                    print("Error",error)
                }
                
            }.resume()
        }
        
        func aat7()
        {
            URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew8)!) as URLRequest) {(data1,reponse,error) in
                do
                {
                    // let JSON = ""
                    //  let jsonData = JSON.data(using: .utf8)!
                    let bbn7: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                    aa7 = bbn7
                    //    print(aa3.title!,aa3.media_type!)
                    
                }
                catch {
                    print("Error",error)
                }
                
            }.resume()
        }
    // ************
    func bbk() {
        remotec.activate()
        remotec.fetch { (status, error) -> Void in
            print("status=",status)
            if status == .success {
            let    apodtitle1 = remotec.configValue(forKey: "spacechunksurl").stringValue!
                qslink =  remotec.configValue(forKey: "spacechunksbg").stringValue!
                print("inside",apodtitle1,qslink)
                
                if (apodtitle1 == "newbackground")
                   {
                   // bbackground = URL(string: qslink)
                    
                     bbackground = qslink
                }
            }
            if status == .failure {
                print("error")
                print("error=",error!)
            }
           print(" entered background",bbackground)
    
         
        }
        print("date",ddate)
        URLSession.shared.dataTask(with: URLRequest(url:URL(string: qslinknew)!) as URLRequest) {(data1,reponse,error) in
            do
            {
                // let JSON = ""
                //  let jsonData = JSON.data(using: .utf8)!
                let bb2: spaceobj1 = try JSONDecoder().decode( spaceobj1.self, from: data1!)
                bb3 = bb2
                print(bb2.title!,bb2.media_type!)
                
            }
            catch {
                print("Error",error)
            }
            
        }.resume()
      
    // }
        
    }
    
    func bb(){
      
       
       URLSession.shared.dataTask(with: URLRequest(url:URL(string: urlink)!) as URLRequest) {(data,reponse,error) in
    do
    {
      //  print("data url sess", data)
    //   let datastring = String(data:data!, encoding: .utf8)
       
            bb1 = try JSONDecoder().decode([spaceobj].self, from: data!)
           // print(bb1)
      
       
    }
    catch
    {
       
    print("There is an error",error)
    }
    }.resume()

           
    }
   
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView( bb3: spaceobj1(date: "", explanation: "", media_type: "", url: ""))
    }
}
