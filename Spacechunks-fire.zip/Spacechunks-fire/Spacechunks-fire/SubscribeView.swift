//
//  SubscribeView.swift
//  Spacechunks-fire
//
//  Created by Gomathy Shankaran on 6/1/23.
//

import SwiftUI
import FirebaseCore
import FirebaseFirestore
import FirebaseCore
struct SubscribeView: View {
    @State var text1 = ""
    @State var text2 = ""
    @State var ffound = false
  //  @State var ref = DocumentReference().init
    @FocusState private var isTouched : Bool
    var body: some View {
        ZStack {
            VStack
             {
                 Text("Subscription Page")
                     .bold()
                     .font(.largeTitle)
                     .frame(width: 300, height: 100, alignment: .center)
                     .foregroundColor(Color.black)
                HStack {
                    Text("Subscribe ")
                    
                    TextField( "Enter email", text: $text1)
                        .focused($isTouched)
                        .foregroundColor(isTouched ?.blue :.black)
                        
                } //Hstack
                .padding(.all)
                Text("Add")
                      .bold()
                      .frame(width: 100, height: 100, alignment: .center)
                      .background(Color.red)
                      .foregroundColor(Color.black)
                      
                      .onTapGesture {
                         // let dinputtoken = db.collection("redact").document("nasdoc")
                          let db = Firestore.firestore()
                          let dinputtoken = db.collection("redact")
                          dinputtoken.getDocuments{ (document, error) in
                             
                              print("same",text1.lowercased())
                            let models = document!.documents.map { document in
                            if let model =  document.get("input"){
                                if ((model as! String).lowercased() == text1.lowercased())
                                      {
                                        let model2 =  document.get("redacted")
                                          print("models exist",model)
                                          ffound = true
                                        text1 = ""
                                        text2 = model2 as! String + "email exists"
                                      }
                                  }
                              }
                              if (ffound == false)
                               {
                                   
                                   let ref = db.collection("redact").addDocument(data: [
                                        "input":text1
                                      ]){ err in
                                          if let err = err {
                                              print("Error adding document: \(err)")
                                              
                                          } else {
                                              text1 = ""
                                              print("Document added")
                                              text2 =  "email subscribed"
                                          }
                                      }
                                   
                               } // add
                              
                              ffound = false
                          }
                       
                  
                      }
                
                Text(text2)
                      .bold()
                      .frame(width: 300, height: 100,alignment: .leading)
                      .foregroundColor(Color.black)
                      .padding(.all)
                              
            } // VStack
        } // Zstack
        .onAppear {
            isTouched = true
        }
    }
}

struct SubscribeView_Previews: PreviewProvider {
    static var previews: some View {
        SubscribeView()
    }
}
