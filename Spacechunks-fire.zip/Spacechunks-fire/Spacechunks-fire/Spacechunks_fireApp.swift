//
//  Spacechunks_fireApp.swift
//  Spacechunks-fire
//
//  Created by Gomathy Shankaran on 5/4/23.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import Firebase

class AppDelegate: NSObject, UIApplicationDelegate {

  func application(_ application: UIApplication,

                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {

    FirebaseApp.configure()
      var handle = Auth.auth().addStateDidChangeListener { auth, user in
        // ...
          
      }
    return true

  }

}


@main

struct Spacechunks_fireApp: App {
 //   init() {
  //      FirebaseApp.configure()
  //  }

    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
        var body: some Scene {
            WindowGroup {
                
                ContentView( bb3: spaceobj1(date: "", explanation: "", media_type: "", url: ""))
            }
        }
    
}
